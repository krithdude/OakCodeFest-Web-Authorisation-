from flask import Flask, render_template,request, url_for
import os
app = Flask(__name__)
app.secret_key = os.urandom(24)


@app.route('/')
def index():
    s = 'bob'
    return render_template('index.html', s=s)


@app.route('/register', methods = ['POST', 'GET'])
def register():
    return render_template('signup.html')


@app.route('/login', methods = ['POST', 'GET'])
def login():
    return render_template('login.html')


@app.route('/stock')
def stock():
    return render_template('stock.html')


if __name__ == '__main__':
    app.run(debug=True)